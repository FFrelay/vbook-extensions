function execute() {
    return Response.success([
        {title: "Latest", input: "https://hentairox.com/?page=1", script: "gen.js"}
    ])
}