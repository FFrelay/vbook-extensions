function execute() {
    return Response.success([
        {title: "Latest", input: "https://hentairox.com/pag/", script: "gen.js"}
    ])
}