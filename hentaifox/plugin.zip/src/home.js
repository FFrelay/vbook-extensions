function execute() {
    return Response.success([
        {title: "Latest", input: "https://hentaifox.com/?page=1", script: "gen.js"}
    ])
}