function execute() {
    return Response.success([
        {title: "New Releases", input: "https://hentaienvy.com/?page=1", script: "gen.js"}
    ])
}