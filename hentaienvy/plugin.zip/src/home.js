function execute() {
    return Response.success([
        {title: "Latest", input: "https://hentaienvy.com/?page=1", script: "gen.js"}
    ])
}