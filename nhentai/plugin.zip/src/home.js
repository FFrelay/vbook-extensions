function execute() {
    return Response.success([
        {title: "Popular Now & New Uploads", input: "https://nhentai.net", script: "gen.js"}
    ]);
}